<?php 
session_start();
include('Proyectoconexion.php');

$stmt = $con->prepare("SELECT * FROM Comandas");
    $stmt->execute();
    $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($filas);
?>