fetch("obtener_productos.php")
      .then(res => res.json())
      .then(data => {
        const select = document.getElementById("id");
        select.innerHTML = '<option value="">-- Selecciona un producto --</option>';
        data.forEach(prod => {
          const option = document.createElement("option");
          option.value = prod.id_Plato;
          option.textContent = prod.nombre_Plato;
          select.appendChild(option);
        });
      })
      .catch(() => {
        document.getElementById("id").innerHTML = "<option>Error al cargar productos</option>";
      });