let carrito = [];
const total=document.getElementById('total');
const menuplatos=document.getElementById('menu');

document.addEventListener("DOMContentLoaded", ()=>{
    fetch("mozocomandas.php")
    .then(res => res.json())
    .then(data => {
        console.log(data);
        data.forEach(plato => {
        menu.innerHTML += `
            <div> 
                <p> <input type="checkbox" onclick="agregarAlCarrito(${plato.id_Plato}, ${plato.precio})" value=${plato.id_Plato} name=id_Plato id=${plato.id_Plato}> ${plato.nombre_Plato}</p>
                <span>${plato.precio}</span>
                <img src= "${plato.imagen}">
            </div>
        `
        

        });
        
    })
})

const tomarPedido=document.getElementById("tomarPedido")
tomarPedido.addEventListener("submit", (e)=> {
    e.preventDefault();

    const form =  new FormData(tomarPedido)
    
    fetch("elegir.php",{
      "method":"POST",
      "body": form
    })
    .then(res=>res.json())
    .then(data =>{
        console.log(data);
        
      if(data.exito){
        console.log("exito")
      }else{
        console.log("error")
      }
    })

})


function agregarAlCarrito(platoId, precio) {

    console.log("...")
    console.log(platoId + " "+ precio);

    localStorage.setItem('idPlato', platoId)
    localStorage.setItem('Precio', precio)

    total.innerHTML=`${precio}`
}


function aplicarPromo() {
    const codigo = document.getElementById("promo").value.trim();
    let descuento = 0;

    if(codigo === "DESCUENTO10") descuento = 0.1; // 10%
    else if(codigo === "DESCUENTO20") descuento = 0.2; // 20%
    else {
        alert("Código promocional inválido");
        return;
    }
    precio = parseFloat(localStorage.getItem('Precio'));
    console.log(precio+ "hola");

    const totalConDescuento = precio - (precio * descuento);
    document.getElementById("total").textContent = totalConDescuento;
    alert(`Código aplicado. Nuevo total: $${totalConDescuento}`);
}
