<?php
include("Proyectoconexion.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $correoMozo = trim($_POST['correoMozo'] ?? '');
    $correoCliente = trim($_POST['correoCliente'] ?? '');
    $fecha = $_POST['fecha'] ?? '';
    $hora = $_POST['hora'] ?? '';
    $cantidad = (int)($_POST['cantidad_Personas'] ?? 0);
    $idMesa = (int)($_POST['id_Mesa'] ?? 0);
    $estado = "Pendiente";

    if (empty($correoMozo) || empty($correoCliente) || empty($fecha) || empty($hora) || $cantidad <= 0 || $idMesa <= 0) {
        die("Faltan datos o son inválidos.");
    }

    try {
        $stmt = $con->prepare("SELECT id_Usuario FROM Usuario WHERE correo = :correo");
        $stmt->execute(['correo' => $correoMozo]);
        $mozo = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$mozo) {
            die("No se encontró el mozo con ese correo.");
        }

        $idMozo = (int)$mozo['id_Usuario'];

        $stmt = $con->prepare("SELECT id_Mozos FROM Mozos WHERE id_Mozos = :id");
        $stmt->execute(['id' => $idMozo]);
        $existeMozo = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$existeMozo) {
            $stmt = $con->prepare("INSERT INTO Mozos (id_Mozos) VALUES (:id)");
            $stmt->execute(['id' => $idMozo]);
        }

        $stmt = $con->prepare("SELECT id_Usuario FROM Usuario WHERE correo = :correo");
        $stmt->execute(['correo' => $correoCliente]);
        $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$cliente) {
            die("No se encontró el cliente con ese correo.");
        }

        $idCliente = (int)$cliente['id_Usuario'];

        $stmt = $con->prepare("SELECT id_Clientes FROM Clientes WHERE id_Clientes = :id");
        $stmt->execute(['id' => $idCliente]);
        $existeCliente = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$existeCliente) {
            $stmt = $con->prepare("INSERT INTO Clientes (id_Clientes) VALUES (:id)");
            $stmt->execute(['id' => $idCliente]);
        }

        $stmt = $con->prepare("INSERT INTO Reserva (fecha, hora, cantidad_Personas, estado_Reserva, id_Clientes, id_Mesa, id_Mozos)VALUES (:fecha, :hora, :cantidad, :estado, :cliente, :mesa, :mozo)
        ");
        $stmt->execute([
            'fecha' => $fecha,
            'hora' => $hora,
            'cantidad' => $cantidad,
            'estado' => $estado,
            'cliente' => $idCliente,
            'mesa' => $idMesa,
            'mozo' => $idMozo
        ]);

        echo "Reserva creada correctamente por el mozo.";

    } catch (PDOException $e) {
        echo "Error al agregar la reserva: " . htmlspecialchars($e->getMessage());
    }
}
?>
