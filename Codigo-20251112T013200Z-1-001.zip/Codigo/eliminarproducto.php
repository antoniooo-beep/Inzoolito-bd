<?php
include("Proyectoconexion.php");

$id = $_POST['id'];

$res = $con->prepare("DELETE FROM Platos WHERE id_Plato = ?");
$res->execute([$id]);

if ($res->rowCount() > 0) {
    echo "<h2>Producto eliminado con éxito.</h2>";
} else {
    echo "<h2>No se encontró el producto o ya fue eliminado.</h2>";
}
?>
