console.log("JS cargado correctamente (eliminarproducto.js)");

fetch("obtener_productos.php")
  .then(res => res.json())
  .then(data => {
    console.log("Productos obtenidos:", data);
    const select = document.getElementById("idEliminar");

    select.innerHTML = '<option value="">-- Selecciona un producto --</option>';
    data.forEach(prod => {
      const option = document.createElement("option");
      option.value = prod.id_Plato;
      option.textContent = prod.nombre_Plato;
      select.appendChild(option);
    });
  })
  .catch(error => {
    console.error("Error al cargar productos:", error);
    document.getElementById("idEliminar").innerHTML =
      "<option>Error al cargar productos</option>";
  });

document.getElementById("formEliminar").addEventListener("submit", function (event) {
  if (!confirm("¿Estás seguro de que quieres eliminar este producto?")) {
    event.preventDefault();
  }
});
