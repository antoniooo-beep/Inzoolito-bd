<?php
include('Proyectoconexion.php');
session_start();

if (!isset($_SESSION['id_cliente'])){
    die ("Error: No se encontró el cliente");
}
$id_cliente = $_SESSION['id_cliente'];
$sql_cliente = "SELECT u.nombre, u.apellido
                FROM Clientes c
                JOIN Usuario u ON c.id_Clientes = u.id_Usuario
                WHERE c.id_Clientes = :id_cliente";
$stmt_cliente = $con->prepare($sql_cliente);
$stmt_cliente->execute([':id_cliente' => $id_cliente]);
$cliente = $stmt_cliente->fetch(PDO::FETCH_ASSOC);

$sql_mesas = "SELECT id_Mesa, ubicacion, capacidad
            FROM Mesa 
            WHERE estado_Mesa = 'Libre'";
$stmt_mesas = $con->query($sql_mesas);
$mesas = $stmt_mesas->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $cantidad_Personas = $_POST['cantidad_Personas'];
    $id_Mesa = $_POST['id_Mesa'];

    if ($cantidad_Personas > 20){
        echo "<script>alert('La cantidad máxima de personas por reserva es 20.'); </script>";
    }else {
        try {
        $sql = "INSERT INTO Reserva (fecha, hora, cantidad_Personas,estado_Reserva, id_Clientes, id_Mesa) 
        VALUES (:fecha, :hora, :cantidad_Personas, 'Activa', :id_Clientes, :id_Mesa)";
        $stmt = $con->prepare($sql);
        $stmt->execute([
            ':fecha' => $fecha,
            ':hora' => $hora,
            ':cantidad_Personas' => $cantidad_Personas,
            ':id_Clientes' => $id_Clientes,
            ':id_Mesa' => $id_Mesa,
        ]);
        
        $update = $con->prepare("UPDATE Mesa SET estado_Mesa = 'Ocupada' WHERE id_Mesa = :id_Mesa");
        $update->execute([':id_Mesa' => $id_Mesa]);

        header('Location: inicio.html');
        exit;
    }catch (PDOException $e) {
        echo "Error al agregar la reserva " .$e->getMessage();
    }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Reservas</title>
</head>
<body>
    <header> 
        <h1> Agregar Reservas </h1>
    </header>
    <main>
        <form action="#" method="POST" id="agregarReserva">
        <label> Cliente: </label>
        <input type="text" value="<?= $cliente['nombre'] . ' ' . $cliente['apellido'] ?>" disabled>

        <div class="form-group">
            <label for="fecha"> Fecha:</label>
            <input type="date" id="fecha" name="fecha" required>
        </div>

        <div class="form-group">
            <label for="hora"> Hora:</label>
            <input type="time" id="hora" name="hora" required>
        </div>

        <div class="form-group">
            <label for="cantidad_Personas"> Cantidad de Personas:</label>
            <input type="number" id="cantidad_Personas" name="cantidad_Personas" required>
        </div>  

        <div class="form-group">
                <label for="id_Mesa"> Seleccione una Mesa:</label>
                <select id="id_Mesa" name="id_Mesa" required>
                    <option value="">Seleccione una mesa</option>
                    <?php foreach ($mesas as $mesa): ?>
                        <option value="<?= $mesa['id_Mesa'] ?>">Mesa <?= $mesa['id_Mesa'] ?> (<?= $mesa['ubicacion'] ?> - capacidad: <?= $mesa['capacidad']?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
        <br>
            <div class="form-group">
                <button type="submit"> Guardar Reserva</button>
                    <a href="inicio.html" class="btn"> Cancelar</a>
            </div>
        </form>
    </main>
</body>
</html>
