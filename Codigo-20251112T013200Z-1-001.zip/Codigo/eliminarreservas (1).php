<?php 
include ('Proyectoconexion.php');
if (isset($_POST['id']) && isset($_POST['confirmar'])) {
    $id_reserva = $_POST['id'];
    
    try {
        $stmt_mesa = $con->prepare("SELECT numero_mesa FROM Reserva WHERE id_reserva = :id_reserva");
        $stmt_mesa->execute([':id_reserva' => $id_reserva]);
        $numero_mesa = $stmt_mesa->fetchColumn();

        $stmt = $con->prepare("DELETE FROM Reserva WHERE id_reserva = :id_reserva");
        $stmt->execute([':id_reserva' => $id_reserva]);
            
        $update = $con->prepare("UPDATE Mesa SET id_estado = 1 WHERE numero_mesa = :numero_mesa");
        $update->execute([':numero_mesa' => $numero_mesa]);

        header('Location: inicio.html');
        exit;
    }catch (PDOException $e) {
        echo "Error al eliminar la reserva " .$e->getMessage();
    }
}
$sql = "SELECT r.id_reserva, r.fecha_reserva, r.hora_reserva, r.numero_mesa, u.nombre, u.apellido
        FROM Reserva r
        JOIN Clientes c ON r.id_cliente = c.id_cliente
        JOIN Usuario u ON c.id_cliente = u.id_usuario
        WHERE r.id_estado_reserva = 1";

$stmt = $con->query($sql);
$reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>