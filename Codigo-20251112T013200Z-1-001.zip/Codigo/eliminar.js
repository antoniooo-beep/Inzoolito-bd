const tabla = document.getElementById("tablaeliminar");

function cargarReservas() {
  fetch("mozoeliminar.php")
    .then(res => res.json())
    .then(data => {
      tabla.innerHTML = `
        <tr>
          <th>ID Reserva</th>
          <th>Fecha</th>
          <th>Hora</th>
          <th>Cantidad Personas</th>
          <th>ID Cliente</th>
          <th>ID Mesa</th>
          <th>Acción</th>
        </tr>
      `;

      data.forEach(reserva => {
        tabla.innerHTML += `
          <tr>
            <td>${reserva.id_Reserva}</td>
            <td>${reserva.fecha}</td>
            <td>${reserva.hora}</td>
            <td>${reserva.cantidad_Personas}</td>
            <td>${reserva.id_Cliente}</td>
            <td>${reserva.id_Mesa}</td>
            <td><button class="btnEliminar" data-id="${reserva.id_Reserva}">Eliminar</button></td>
          </tr>
        `;
      });

      document.querySelectorAll(".btnEliminar").forEach(boton => {
        boton.addEventListener("click", (e) => {
          const id = e.target.dataset.id;
          eliminarReserva(id);
        });
      });
    });
}

function eliminarReserva(id) {
  fetch("mozoeliminar.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: `id_Reserva=${id}`
  })
  .then(res => res.json())
  .then(resp => {
    if (resp.success) {
      alert("Reserva eliminada correctamente");
      cargarReservas(); 
    } else {
      alert("Error al eliminar la reserva");
    }
  });
}

document.addEventListener("DOMContentLoaded", cargarReservas);
