<?php
include('Proyectoconexion.php');

if (isset($_POST['id_Reserva'])) {
    $id = $_POST['id_Reserva'];
    $stmt = $con->prepare("DELETE FROM Reserva WHERE id_Reserva = ?");
    $stmt->execute([$id]);
    echo json_encode(["success" => true]);
    exit;
}

$stmt = $con->prepare("SELECT * FROM Reserva");
$stmt->execute();
$reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($reservas);
?>



