const menu_contenedor=document.getElementById("menu-contenedor")

document.addEventListener("DOMContentLoaded", ()=>{
    fetch("menu_cargar.php")
    .then(res => res.json())
    .then(data => {
        console.log(data);
        data.forEach(plato => {
        menu_contenedor.innerHTML += `
            <div>
                <p>${plato.nombre_Plato}</p>
                <p>${plato.descripcion}</p>
                <p>${plato.tiempo_Preparacion}</p>
                <span>${plato.precio}</span>
                <span>${plato.categoria}</span>
                <img src= "${plato.imagen}">
            </div>
        `

        });
        
    })
})