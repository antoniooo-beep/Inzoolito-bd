const menu=document.getElementById("menu")

document.addEventListener("DOMContentLoaded", ()=>{
    fetch("mozocomandas.php")
    .then(res => res.json())
    .then(data => {
        console.log(data);
        data.forEach(plato => {
        menu.innerHTML += `
            <div> 
                <p> <input type="checkbox" value=${plato.id_Plato} name=id_Plato id=${plato.id_Plato}> ${plato.nombre_Plato}</p>
                <span>${plato.precio}</span>
                <img src= "${plato.imagen}">
            </div>
        `

        });
        
    })
})

const tomarPedido=document.getElementById("tomarPedido")
tomarPedido.addEventListener("submit", (e)=> {
    e.preventDefault();

    const form =  new FormData(tomarPedido)
    
    fetch("elegir.php",{
      "method":"POST",
      "body": form
    })
    .then(res=>res.json())
    .then(data =>{
        console.log(data);
        
      if(data.exito){
        console.log("exito")
      }else{
        console.log("error")
      }
    })

})
