<?php
session_start();
include("Proyectoconexion.php");

$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_Plato = $_POST["id_Plato"] ?? "";
    $id_Mesa = $_POST["id_Mesa"] ?? "";
    $observaciones = $_POST["observaciones"] ?? "";
    $restricciones = $_POST["restricciones"] ?? "";
    $observaciones = trim($observaciones);
    $restricciones = trim($restricciones);
    

    if ($id_Mesa == "" || $id_Plato == "") {
        $error = "Por favor, complete todos los campos.";
        echo json_encode(["error" => $error]);
    } else {
        $sql = "INSERT INTO Comandas (observaciones,id_Mesa, id_Plato, restriccion) VALUES (?,?,?,?)";
        $stmt = $con->prepare($sql);
        $stmt->execute([$observaciones, $id_Mesa, $id_Plato, $restricciones]);
            echo json_encode(["exito" => true]);        
    }
}
?>