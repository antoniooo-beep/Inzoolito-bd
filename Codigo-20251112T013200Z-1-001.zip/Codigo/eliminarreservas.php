<?php 
include ('Proyectoconexion.php');
if (isset($_POST['id']) && isset($_POST['confirmar'])) {
    $id_reserva = $_POST['id'];
    
    try {
        $stmt_mesa = $con->prepare("SELECT id_mesa FROM Reserva WHERE id_Reserva = :id_reserva");
        $stmt_mesa->execute([':id_reserva' => $id_reserva]);
        $numero_mesa = $stmt_mesa->fetchColumn();

        if ($id_mesa) {
            $stmt = $con->prepare("DELETE FROM Reserva WHERE id_Reserva = :id_reserva");
            $stmt->execute([':id_reserva' => $id_reserva]);

            $update = $con->prepare("UPDATE Mesa SET estaod_Mesa = 'Disponible' WHERE id_Mesa = :id_mesa");
            $update->execute([':id_mesa' => $id_mesa]);
        }

        header('Location: inicio.html');
        exit;
    }catch (PDOException $e) {
        echo "Error al eliminar la reserva " .$e->getMessage();
    }
}
$sql = "SELECT r.id_Reserva, r.fecha, r.hora, r.cantidad_Personas, m.id_Mesa, m.ubicacion, u.nombre, u.apellido
        FROM Reserva r
        JOIN Clientes c ON r.id_Clientes = c.id_Clientes
        JOIN Usuario u ON c.id_Clientes = u.id_Usuario
        JOIN Mesa m ON r.id_Mesa = m.id_Mesa
        WHERE r.estado_Reserva = 'Activa'";

$stmt = $con->query($sql);
$reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Eliminar Reservas</title>
</head>
<body>
    <header> 
        <h1> Eliminar Reservas </h1>
    </header>
    <?php if (count($reservas) > 0): ?>
        <table border="1" cellpadding="8">
            <tr>
                <td>ID Reserva</td>
                <td>Cliente</td>
                <td>Fecha</td>
                <td>Hora</td>
                <td>Cantidad Personas</td>
                <td>Mesa</td>
                <td>Ubicación</td>
                <td>Acción</td>
            </tr>
            <?php foreach ($reservas as $reserva): ?>
                <tr>
                    <td><?= htmlspecialchars($reserva['id_Reserva']) ?></td>
                    <td><?= htmlspecialchars($reserva['nombre'] . ' ' . $reserva['apellido']) ?></td>
                    <td><?= htmlspecialchars($reserva['fecha']) ?></td>
                    <td><?= htmlspecialchars($reserva['hora']) ?></td>
                    <td><?= htmlspecialchars($reserva['cantidad_Personas']) ?></td>
                    <td><?= $reserva['id_Mesa'] ?></td>
                    <td>
                    <td><?= $reserva['ubicacion'] ?></td>
                    <td>
                        <form action="#" method="POST">
                            <input type="hidden" name="id" value="<?= $reserva['id_reserva'] ?>">
                            <button type="submit" name="confirmar" value="1">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No hay reservas activas.</p>
    <?php endif; ?>

    <br>
    <a href="inicio.html">Volver al inicio</a>
</body>
</html>
