<?php
include("Proyectoconexion.php");

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$desc = $_POST['desc'];
$tiempo = $_POST['tiempo'];
$precio = $_POST['precio'];
$cate = $_POST['cate'];

$res = $con->prepare("UPDATE Platos 
                      SET nombre_Plato = ?, descripcion = ?, tiempo_Preparacion = ?, precio = ?, categoria = ?
                      WHERE id_Plato = ?");
$res->execute([$nombre, $desc, $tiempo, $precio, $cate, $id]);

if ($res->rowCount() > 0) {
    echo "<h2> Producto modificado con éxito.</h2>";
} else {
    echo "<h2> No se realizaron cambios o el producto no existe.</h2>";
}
?>
