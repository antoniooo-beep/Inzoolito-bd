<?php 
session_start();
include('Proyectoconexion.php');

header('Content-Type: application/json; charset=utf-8');

    $stmt = $con->prepare("SELECT * FROM Platos LIMIT 3");
    $stmt->execute();
    $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);



    echo json_encode($filas);
?>
