<?php 
include ("Proyectoconexion.php");
$nombre = $_POST['nombre'];
$desc = $_POST['desc'];
$tiempo = $_POST['tiempo'];
$precio = $_POST['precio'];
$cate = $_POST['cate'];
$imagen = null;

$res = $con -> prepare("INSERT INTO Platos (nombre_Plato, descripcion ,tiempo_Preparacion, precio, categoria, imagen) values(?,?,?,?,?,?)");
$res -> execute ([$nombre, $desc, $tiempo, $precio, $cate, $imagen]);
echo "<h2> Producto ingresado con éxito!</h2>";

?>