document.addEventListener("DOMContentLoaded", function () {
    const perfilInput = document.getElementById("perfil");
    const divCodigo = document.getElementById("divCodigo");
    const codigoInput = document.getElementById("codigo");
    const formulario = document.getElementById("formulario");

    const perfiles = {
        "gerente general": { codigo: "001", panel: "gerentegeneral.html" },
        "gerente de turno": { codigo: "002", panel: "gerenteturno.html" },
        "mozo": { codigo: "003", panel: "mozo.html" },
        "cocinero": { codigo: "004", panel: "cocinero.html" },
        "chef ejecutivo": { codigo: "005", panel: "chefejecutivo.html"},
        "cliente": { codigo: null, panel: "inicio.html"}
    };

    perfilInput.addEventListener("change", function () {
        const perfil = perfilInput.value.trim().toLowerCase();
        if (perfiles[perfil] && perfiles[perfil].codigo !== null) {
            divCodigo.style.display = "block"; 
        } else {
        divCodigo.style.display = "none";
        }
    });

    formulario.addEventListener("submit", function (e) {
        e.preventDefault();

        const perfil = perfilInput.value.trim().toLowerCase();
        const codigoIngresado = codigoInput.value.trim();

        if (perfiles[perfil]) {
            const { codigo, panel } = perfiles[perfil];
            if (codigo === null) {
                window.location.href = panel;
                return;
            }
            if (codigoIngresado === codigo) {
                window.location.href = panel;
            } else {
                alert("Código incorrecto para el perfil ingresado.");
            }
        } else {
            alert("Perfil no válido. Ingresá uno de los siguientes: Cocinero, Mozo, Gerente General, Chef Ejecutivo, Gerente de Turno.");
        }
    });
});
