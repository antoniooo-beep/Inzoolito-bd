<?php 
include ('../Proyectoconexion.php');

if(isset($_GET['inicio'])){
    $stmt = $con->prepare("SELECT * FROM Platos LIMIT 6");
    $stmt->execute();
    $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);

}else if(isset($_GET['cat'])){
    $cat = $_GET['cat'];
    $stmt = $con->prepare("SELECT * FROM Platos WHERE categoria=? LIMIT 6");
    $stmt->execute([$cat]);
    $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);
}else{

    $stmt = $con->prepare("SELECT * FROM Platos");
    $stmt->execute();
    $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);
}


    echo json_encode($filas);


?>