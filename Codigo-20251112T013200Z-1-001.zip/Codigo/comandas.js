const tablacomanda=document.getElementById("tablacomanda")

function cargarComandas() {
    fetch("comandamozo.php")
    .then(res => res.json())
    .then(data => {
        tablacomanda.innerHTML = `
            <tr>
                <th>ID Comanda</th>
                <th>ID Mesa</th>
                <th>ID Plato</th>
                <th>Observaciones</th>
                <th>Restricción</th>
            </tr>
        `;
        data.forEach(comanda => {
            console.log(comanda);
        tablacomanda.innerHTML += `
            <tr>
                <td>${comanda.id_Comanda}</td>
                <td>${comanda.id_Mesa}</td>
                <td>${comanda.id_Plato}</td>
                <td>${comanda.observaciones}</td>
                <td>${comanda.restriccion}</td>
            </tr>
        `;
        });
    })
    .catch(error => console.error("Error al cargar comandas:", error));
}
document.addEventListener("DOMContentLoaded", ()=>{
    cargarComandas();

    const boton = document.getElementById("btnActualizar");
    if (boton) {
        boton.addEventListener("click", (e) => {
            e.preventDefault(); 
            cargarComandas();
        });
    }
    setInterval(cargarComandas, 5000);
});