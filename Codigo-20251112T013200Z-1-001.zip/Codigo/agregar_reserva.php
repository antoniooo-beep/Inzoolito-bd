<?php
include("Proyectoconexion.php"); 

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $correo = trim($_POST['correo'] ?? '');
    $fecha = $_POST['fecha'] ?? '';
    $hora = $_POST['hora'] ?? '';
    $cantidad = (int)($_POST['cantidad_Personas'] ?? 0);
    $idMesa = (int)($_POST['id_Mesa'] ?? 0);
    $estado = "Pendiente";

    if (empty($correo) || empty($fecha) || empty($hora) || $cantidad <= 0 || $idMesa <= 0) {
        die("⚠️ Por favor, completá todos los campos correctamente.");
    }

    try {
        $stmt = $con->prepare("SELECT id_Usuario FROM Usuario WHERE correo = :correo");
        $stmt->execute(['correo' => $correo]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario) {
            $idUsuario = (int)$usuario['id_Usuario'];

            $stmt = $con->prepare("SELECT id_Clientes FROM Clientes WHERE id_Clientes = :id");
            $stmt->execute(['id' => $idUsuario]);
            $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($cliente) {
                $idCliente = (int)$cliente['id_Clientes'];
            } else {
                $stmt = $con->prepare("INSERT INTO Clientes (id_Clientes) VALUES (:id)");
                $stmt->execute(['id' => $idUsuario]);
                $idCliente = $idUsuario;
            }

            $stmt = $con->prepare("INSERT INTO Reserva (fecha, hora, cantidad_Personas, estado_Reserva, id_Clientes, id_Mesa, id_Mozos)VALUES (:fecha, :hora, :cantidad, :estado, :cliente, :mesa, NULL)");
            $stmt->execute([
                'fecha' => $fecha,
                'hora' => $hora,
                'cantidad' => $cantidad,
                'estado' => $estado,
                'cliente' => $idCliente,
                'mesa' => $idMesa
            ]);

            echo "✅ Reserva agregada correctamente.";
        } else {
            echo "⚠️ No se encontró ningún usuario con ese correo.";
        }

    } catch (PDOException $e) {
        echo "❌ Error al guardar la reserva: " . htmlspecialchars($e->getMessage());
    }
} else {
    echo "Acceso no válido.";
}
?>
