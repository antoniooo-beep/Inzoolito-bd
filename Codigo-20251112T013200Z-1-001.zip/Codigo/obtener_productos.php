<?php
include("Proyectoconexion.php");

$stmt = $con->query("SELECT id_Plato, nombre_Plato FROM Platos");
$productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json; charset=utf-8');
echo json_encode($productos);
?>
